export const environment = {
  production: true,
  imageApiUrl: 'http://vocatutor.azurewebsites.net/api/image/'
};
