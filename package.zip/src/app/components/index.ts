export * from './tester/tester.component';
export * from './vocabulary/vocabulary.component';
export * from './app/app.component';
