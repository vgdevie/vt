export enum TestTypeEnum {
  ValueTranslation = 1, TranslationValue = 2, ValueTranlationWriting = 3, ValueTranslationAudio = 4
}
