export class TestAnswer {
  constructor(public value: string, public translation: string, public correct: boolean) { }
  picked: boolean;
}
