export enum TestGradeEnum {
  Excellent = 0, VeryGood = 1, Good = 2, Pass = 3, Fail = 4
}
