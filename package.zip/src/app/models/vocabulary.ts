import { Word } from ".";

export class Vocabulary {
  words: Word[];
  valueLang: string;
  translaionLang: string;
  title: string;
}
