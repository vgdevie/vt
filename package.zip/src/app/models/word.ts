export class Word {
  constructor(public value: string, public translation: string) {}
  public thumbnailUrl: string;
}
